package com.example.smartgarden

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.snackbar.Snackbar

open class BaseMenuActivity : AppCompatActivity() {

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        setupToolbar()
    }

    private fun setupToolbar() {
        val toolbar: Toolbar? = findViewById(R.id.toolbar)
        toolbar?.let {
            setSupportActionBar(it)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_principal, menu)

        // Ocultar el ítem del menú correspondiente a la pantalla actual
        when (this) {
            is HomeActivity -> menu.findItem(R.id.action_home)?.isVisible = false
            is SettingsActivity -> menu.findItem(R.id.action_settings)?.isVisible = false
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_home -> {
            if (this !is HomeActivity) {
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }
            true
        }
        R.id.action_settings -> {
            if (this !is SettingsActivity) {
                startActivity(Intent(this, SettingsActivity::class.java))
                finish()
            }
            true
        }
        R.id.action_logout -> {
            // Mostrar Snackbar con el texto requerido
            Snackbar.make(
                findViewById(android.R.id.content),
                "Sesión cerrada correctamente.",
                Snackbar.LENGTH_LONG
            ).show()
            true
        }
        android.R.id.home -> {
            // Manejar el botón de retroceso de la toolbar
            onBackPressed()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}