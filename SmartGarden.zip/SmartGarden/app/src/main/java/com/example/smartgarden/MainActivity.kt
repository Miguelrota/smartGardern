package com.example.smartgarden

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar

class MainActivity : BaseMenuActivity() {

    private lateinit var btnGuardar: Button
    private lateinit var btnMostrarAviso: Button
    private lateinit var btnEnviarNotificacion: Button
    private lateinit var etNombre: EditText


    private val CHANNEL_ID = "smart_garden_channel"
    private val NOTIFICATION_ID = 1


    private var nombrePlantaTemporal: String = ""


    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {

            enviarNotificacion()
        } else {

            Toast.makeText(this, "Permiso denegado. No se puede enviar notificación.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        crearCanalNotificacion()


        btnGuardar = findViewById(R.id.btnGuardar)
        btnMostrarAviso = findViewById(R.id.btnMostrarAviso)
        btnEnviarNotificacion = findViewById(R.id.btnEnviarNotificacion)
        etNombre = findViewById(R.id.etNombre)


        btnGuardar.setOnClickListener {
            mostrarDialogoConfirmacion()
        }

        btnMostrarAviso.setOnClickListener {
            mostrarAviso()
        }

        btnEnviarNotificacion.setOnClickListener {
            enviarNotificacionConPermiso()
        }


        supportActionBar?.title = "Smart Garden"
    }

    private fun mostrarDialogoConfirmacion() {
        val nombrePlanta = etNombre.text.toString().trim()

        if (nombrePlanta.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa un nombre para la planta", Toast.LENGTH_SHORT).show()
            return
        }


        nombrePlantaTemporal = nombrePlanta


        val dialog = ConfirmDialog()
        dialog.setListener(object : ConfirmDialog.ConfirmDialogListener {
            override fun onDialogPositiveClick() {

                Snackbar.make(
                    findViewById(R.id.main),
                    "Datos guardados",
                    Snackbar.LENGTH_LONG
                ).show()

                // Limpiar el campo después de guardar
                etNombre.text.clear()
                nombrePlantaTemporal = ""
            }

            override fun onDialogNegativeClick() {

                Toast.makeText(this@MainActivity, "Operación cancelada", Toast.LENGTH_SHORT).show()

                // Limpiar la variable temporal
                nombrePlantaTemporal = ""
            }
        })
        dialog.show(supportFragmentManager, "ConfirmDialog")
    }

    private fun crearCanalNotificacion() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Smart Garden Notificaciones"
            val descriptionText = "Notificaciones del sistema de riego automático"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }


            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun enviarNotificacionConPermiso() {
        // Verificar si tenemos permiso (Android 13+ requiere POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    // Ya tenemos permiso, enviar notificación
                    enviarNotificacion()
                }
                ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) -> {
                    // Explicar al usuario por qué necesitamos el permiso
                    Snackbar.make(
                        findViewById(R.id.main),
                        "Se necesita permiso para mostrar notificaciones del sistema de riego",
                        Snackbar.LENGTH_LONG
                    ).setAction("OTORGAR") {
                        requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }.show()
                }
                else -> {
                    // Pedir permiso directamente
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        } else {
            // Para versiones anteriores a Android 13, no se necesita permiso explícito
            enviarNotificacion()
        }
    }

    private fun enviarNotificacion() {

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent: PendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )


        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // Icono temporal
            .setContentTitle("Smart Garden")
            .setContentText("Riego automático activado a las 20:00 🌱")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent) // Abre la app al pulsar
            .setAutoCancel(true) // Se cierra al pulsarla


        with(NotificationManagerCompat.from(this)) {
            if (ActivityCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                Toast.makeText(this@MainActivity, "No se tienen permisos para mostrar notificaciones", Toast.LENGTH_SHORT).show()
                return
            }
            notify(NOTIFICATION_ID, builder.build())
            Toast.makeText(this@MainActivity, "Notificación enviada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun mostrarAviso() {
        val snackbar = Snackbar.make(
            findViewById(R.id.main),
            "Aviso mostrado correctamente",
            Snackbar.LENGTH_LONG
        )

        snackbar.setAction("Deshacer") {
            Toast.makeText(this, "Acción cancelada", Toast.LENGTH_SHORT).show()
        }

        snackbar.show()
    }
}