package com.example.smartgarden


import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.DialogFragment

class ConfirmDialog : DialogFragment() {

    interface ConfirmDialogListener {
        fun onDialogPositiveClick()
        fun onDialogNegativeClick()
    }

    private var listener: ConfirmDialogListener? = null

    fun setListener(listener: ConfirmDialogListener) {
        this.listener = listener
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            .setTitle("Confirmar guardado")
            .setMessage("¿Deseas guardar los datos de esta planta?")
            .setPositiveButton("Aceptar") { dialog, which ->
                listener?.onDialogPositiveClick()
            }
            .setNegativeButton("Cancelar") { dialog, which ->
                listener?.onDialogNegativeClick()
            }
            .create()
    }
}