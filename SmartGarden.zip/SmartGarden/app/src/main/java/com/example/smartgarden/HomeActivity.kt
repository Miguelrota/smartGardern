package com.example.smartgarden

import android.os.Bundle

class HomeActivity : BaseMenuActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Configurar título en la toolbar
        supportActionBar?.title = "Inicio"
    }
}