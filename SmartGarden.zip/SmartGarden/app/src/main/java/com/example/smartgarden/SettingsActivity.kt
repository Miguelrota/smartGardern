package com.example.smartgarden

import android.os.Bundle
import android.widget.TextView

class SettingsActivity : BaseMenuActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Configurar título en la toolbar
        supportActionBar?.title = "Ajustes"
    }
}